---
name: Whiskered project context
description: All 19 tabs in the Whiskered site are unblocked game websites, not generic community platforms
type: project
---

All 19 tabs (Cherri, Nexora, Overcloaked, Void Network, Galaxy, Fern, Axis, Xylora, Quasar, Infamous, Truffled, UniUB, DogeUB, Lunar, Frogies arcade, Interstellar, Shadow, Selenite, Duckmath) are unblocked game websites — browser-based gaming portals meant to be accessible on school/work networks.

**Why:** User clarified after initial placeholder content was too generic (community hubs, wellness platforms, etc.). Content should reflect unblocked gaming: game counts, player counts, features like bypass/proxy, leaderboards, dark mode, retro/arcade, etc.

**How to apply:** When writing descriptions, tags, or stats for any of these tabs, frame them as unblocked game sites with gaming-relevant details.
